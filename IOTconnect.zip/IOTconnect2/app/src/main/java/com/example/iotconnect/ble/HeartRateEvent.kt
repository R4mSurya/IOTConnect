package com.example.iotconnect.ble

data class HeartRateEvent(val heartRate: Int)
