package com.example.iotconnect.ble

import android.annotation.SuppressLint
import android.bluetooth.BluetoothA2dp
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothProfile
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.example.iotconnect.R
import com.example.iotconnect.databinding.ActivityBleMain2Binding
import com.example.iotconnect.databinding.ActivityBleMainBinding
import com.jjoe64.graphview.GraphView
import com.jjoe64.graphview.series.DataPoint
import com.jjoe64.graphview.series.LineGraphSeries
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import java.util.Date


class bleMainActivity2 : AppCompatActivity() {
    lateinit var name : TextView
    lateinit var address : TextView
    lateinit var rssid : TextView
    lateinit var disconnt : Button
    private var bluetoothGatt: BluetoothGatt? = null
    //private lateinit var heartRateViewModel: HeartRateViewModel
    private lateinit var graphView: GraphView
    private val heartRateDataPoints: MutableList<DataPoint> = mutableListOf()
    private lateinit var binding : ActivityBleMain2Binding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBleMain2Binding.inflate(layoutInflater)
        setContentView(binding.root)
        name = findViewById(R.id.name2)
        address = findViewById(R.id.macAddress)
        rssid = findViewById(R.id.rssid)
        //heartRateViewModel = ViewModelProvider(this).get(HeartRateViewModel::class.java)
        Toast.makeText(this@bleMainActivity2, "Successfully connected!", Toast.LENGTH_SHORT).show()
        val bundle = intent.extras
        if (bundle != null){
            name.text = "Name = ${bundle.getString("name")}"
            address.text = "BSSID = ${bundle.getString("macaddress")}"
            rssid.text = "RSSI = ${bundle.getInt("rssi")} dBm"
//            val services = intent.getStringArrayListExtra("services")
//            binding.servicesTextView.text = services?.joinToString("\n")
//            val meaningsList = intent.getStringArrayListExtra("meanings")
//            binding.servicesTextView.text = meaningsList?.joinToString("\n")
//                heartRateViewModel.heartRateLiveData.observe(this) { heartRate ->
//                    Log.i("finalem", "$heartRate")
//                    binding.heartvalue.text = heartRate.toString()
//                }

            val app = application as MyApplication
            bluetoothGatt = app.bluetoothGatt
        }

        graphView = findViewById<GraphView>(R.id.graphView)
        graphView.title = "Heart Rate Graph"
        graphView.gridLabelRenderer.horizontalAxisTitle = "Time"
        graphView.gridLabelRenderer.verticalAxisTitle = "Heart Rate"
        graphView.viewport.isScalable = false

        disconnt = findViewById(R.id.discont)
        disconnt.setOnClickListener {
            disconnect()
            Toast.makeText(this@bleMainActivity2, "Disconnected Successfully", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    override fun onStart() {
        super.onStart()
        EventBus.getDefault().register(this)
    }

    override fun onStop() {
        EventBus.getDefault().unregister(this)
        super.onStop()
    }

    @Subscribe
    fun onHeartRateEvent(event: HeartRateEvent) {
        val heartRate = event.heartRate
        Log.i("halem", "$heartRate")
        runOnUiThread {
            binding.heartvalue.text = "Heart Rate : "+heartRate.toString()+" bpm"
        }
        val time = Date(System.currentTimeMillis())
        heartRateDataPoints.add(DataPoint(time, heartRate.toDouble()))

        // Update the graph
        updateGraph()
    }

    private fun updateGraph() {
        // Create a new series with the updated data points
        val series = LineGraphSeries<DataPoint>(heartRateDataPoints.toTypedArray())

        // Remove any existing series from the graph
        graphView.removeAllSeries()

        // Add the new series to the graph
        graphView.addSeries(series)

        // Set the viewport to show all the data points
        graphView.viewport.setMinX(heartRateDataPoints.firstOrNull()?.x ?: 0.0)
        graphView.viewport.setMaxX(heartRateDataPoints.lastOrNull()?.x ?: 0.0)
        graphView.viewport.setMinY(heartRateDataPoints.minOfOrNull { it.y }?.minus(10) ?: 0.0)
        graphView.viewport.setMaxY(heartRateDataPoints.maxOfOrNull { it.y }?.plus(10) ?: 100.0)

        // Refresh the graph
        graphView.invalidate()
    }

    @SuppressLint("MissingPermission")
    private fun disconnect() {
        bluetoothGatt?.disconnect()
        bluetoothGatt?.close()
        bluetoothGatt = null
    }


}