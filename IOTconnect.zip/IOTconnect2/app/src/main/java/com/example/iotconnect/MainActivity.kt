package com.example.iotconnect

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.iotconnect.ble.bleMainActivity
import com.example.iotconnect.wifi.wifiMainActivity
import com.example.iotconnect.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.ble.setOnClickListener {
            val intent = Intent(this@MainActivity, bleMainActivity::class.java)
            startActivity(intent)
        }
        binding.wifi.setOnClickListener {
            val intent = Intent(this@MainActivity, wifiMainActivity::class.java)
            startActivity(intent)
        }
        binding.nfc.setOnClickListener {
            Toast.makeText(this, "Yet to implement", Toast.LENGTH_SHORT).show()
        }
    }
}