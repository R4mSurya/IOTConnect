package com.example.iotconnect.ble

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class HeartRateViewModel : ViewModel() {
    private val _heartRateLiveData = MutableLiveData<Int>()
    val heartRateLiveData: LiveData<Int>
        get() = _heartRateLiveData

    fun updateHeartRate(heartRate: Int) {
        _heartRateLiveData.postValue(heartRate)
    }
}
